    </main>
    <footer class="main-footer">
        <div class="footer-container">
            <p>&copy; <?php echo date("Y"); ?> ClinicSys. All rights reserved. | Modern Health Solutions</p>
            <!-- Add any other footer links or info here -->
        </div>
    </footer>
    <script src="js/animations.js"></script> <!-- General animations -->
    <script src="js/dashboard_animations.js"></script> <!-- Dashboard specific animations -->
</body>
</html>

